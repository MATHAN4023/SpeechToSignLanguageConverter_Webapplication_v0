# Audio-Speech-To-Sign-Language-Converter

This project is a full-stack application that converts audio speech to sign language. It consists of a Python backend server and a React frontend client.

## Prerequisites

- Python 3.x
- Node.js and npm
- Git

## Project Structure

```
.
├── Server/          # Python backend
├── Client/          # React frontend
└── start_servers.bat # Script to start both servers
```

## Setup Instructions

### Backend Setup (Server)

1. Navigate to the Server directory:
   ```bash
   cd Server
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   ```

3. Activate the virtual environment:
   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - Linux/Mac:
     ```bash
     source venv/bin/activate
     ```

4. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Run the NLTK data download script:
   ```bash
   python download_nltk_data.py
   ```

### Frontend Setup (Client)

1. Navigate to the Client directory:
   ```bash
   cd Client
   ```

2. Install Node.js dependencies:
   ```bash
   npm install
   ```

## Running the Application

### Windows
Simply run the `start_servers.bat` script from the root directory.

### Manual Start
1. Start the backend server:
   ```bash
   cd Server
   python app.py
   ```

2. Start the frontend development server:
   ```bash
   cd Client
   npm run dev
   ```

The application will be available at:
- Frontend: http://localhost:5173
- Backend: http://localhost:5000

## Notes
- Make sure both servers are running simultaneously
- The backend server must be running before the frontend can connect to it
- Check the console for any error messages if the application doesn't start properly

## Troubleshooting
If you encounter any issues:
1. Ensure all dependencies are installed correctly
2. Check if the required ports (5000 and 5173) are not in use
3. Verify that both servers are running
4. Check the console logs for any error messages 